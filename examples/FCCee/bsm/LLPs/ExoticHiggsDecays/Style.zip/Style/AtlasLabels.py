from ROOT import *
gROOT.LoadMacro("AtlasLabels.C")

